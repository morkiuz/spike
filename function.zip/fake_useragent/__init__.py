from fake_useragent.errors import FakeUserAgentError, UserAgentError
from fake_useragent.fake import FakeUserAgent, UserAgent
from fake_useragent.settings import __version__ as VERSION
